﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp6
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }

        MeshGeometry3D mymesh = new MeshGeometry3D();

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }
    }

    public class Tasks: IMultiValueConverter
    {
        private string taskName;
        private string description;
        private int priority;
        public enum TaskType
        {
            Home,Work
        }

        public string TaskName
        {
            get {return this.taskName; }
            set { value = taskName; }
        }

        public string Description
        {
            get {return this.description; }
            set { value = description; }
        }

        public int Priority
        {
            get { return this.priority; }
            set { value = priority; }
        }

        object IMultiValueConverter.Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        object[] IMultiValueConverter.ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
