﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Globalization;

namespace arcProgressBar
{
    public class RichTickBar: FrameworkElement
    {

        // --------------------------------------------------------------------------------------------
        #region Minimum & Maximum

            //控件默认最小值为0.0
        public static readonly DependencyProperty MinimumProperty = RangeBase.MinimumProperty.AddOwner(typeof(RichTickBar),
            new FrameworkPropertyMetadata(0.0, FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsRender));

        [Category("Behavior")]
        public double Minimum
        {
            get { return (double)GetValue(MinimumProperty); }
            set { SetValue(MinimumProperty, value); }
        }


        //控件默认最大值为100.0
        public static readonly DependencyProperty MaximumProperty = RangeBase.MaximumProperty.AddOwner(typeof(RichTickBar),
            new FrameworkPropertyMetadata(100.0, FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsRender));

        [Category("Behavior")]
        public double Maximum
        {
            get { return (double)GetValue(MaximumProperty); }
            set { SetValue(MaximumProperty, value); }
        }

        #endregion Minimum & Maximum



        // --------------------------------------------------------------------------------------------
        #region Small Ticks: Step, Size, Brush

            //设置最小步长
        public static readonly DependencyProperty SmallTickStepProperty = DependencyProperty.RegisterAttached(
            "SmallTickStep", typeof(double), typeof(RichTickBar),
            new FrameworkPropertyMetadata(5.0, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        [Category("Behavior")]
        public double SmallTickStep
        {
            get { return (double)GetValue(SmallTickStepProperty); }
            set { SetValue(SmallTickStepProperty, value); }
        }

        public static void SetSmallTickStep(DependencyObject elem, double value)
        {
            elem.SetValue(SmallTickStepProperty, value);
        }

        public static double GetSmallTickStep(DependencyObject elem)
        {
            return (double)elem.GetValue(SmallTickStepProperty);
        }




        public static readonly DependencyProperty SmallTickSizeProperty = DependencyProperty.RegisterAttached(
            "SmallTickSize", typeof(Size), typeof(RichTickBar),
            new FrameworkPropertyMetadata(new Size(1, 5), FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        [Category("Appearance")]
        public Size SmallTickSize
        {
            get { return (Size)GetValue(SmallTickSizeProperty); }
            set { SetValue(SmallTickSizeProperty, value); }
        }

        public static void SetSmallTickSize(DependencyObject elem, Size value)
        {
            elem.SetValue(SmallTickSizeProperty, value);
        }

        public static Size GetSmallTickSize(DependencyObject elem)
        {
            return (Size)elem.GetValue(SmallTickSizeProperty);
        }




        public static readonly DependencyProperty SmallTickBrushProperty = DependencyProperty.RegisterAttached(
            "SmallTickBrush", typeof(Brush), typeof(RichTickBar),
            new FrameworkPropertyMetadata(Brushes.Black, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        public Brush SmallTickBrush
        {
            get { return (Brush)GetValue(SmallTickBrushProperty); }
            set { SetValue(SmallTickBrushProperty, value); }
        }

        public static void SetSmallTickBrush(DependencyObject elem, Brush value)
        {
            elem.SetValue(SmallTickBrushProperty, value);
        }

        public static Brush GetSmallTickBrush(DependencyObject elem)
        {
            return (Brush)elem.GetValue(SmallTickBrushProperty);
        }

        #endregion Small Ticks: Step, Radius, Alignment, Size, Brush




        // --------------------------------------------------------------------------------------------
        #region Large Ticks: Step, Size, Brush

            //控制步长，默认5
        public static readonly DependencyProperty LargeTickStepProperty = DependencyProperty.RegisterAttached(
            "LargeTickStep", typeof(double), typeof(RichTickBar),
            new FrameworkPropertyMetadata(25.0, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        [Category("Behavior")]
        public double LargeTickStep
        {
            get { return (double)GetValue(LargeTickStepProperty); }
            set { SetValue(LargeTickStepProperty, value); }
        }

        public static void SetLargeTickStep(DependencyObject elem, double value)
        {
            elem.SetValue(LargeTickStepProperty, value);
        }

        public static double GetLargeTickStep(DependencyObject elem)
        {
            return (double)elem.GetValue(LargeTickStepProperty);
        }



        //控制大刻度的宽度和高度
        public static readonly DependencyProperty LargeTickSizeProperty = DependencyProperty.RegisterAttached(
            "LargeTickSize", typeof(Size), typeof(RichTickBar),
            new FrameworkPropertyMetadata(new Size(2, 10), FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        [Category("Appearance")]
        public Size LargeTickSize
        {
            get { return (Size)GetValue(LargeTickSizeProperty); }
            set { SetValue(LargeTickSizeProperty, value); }
        }

        public static void SetLargeTickSize(DependencyObject elem, Size value)
        {
            elem.SetValue(LargeTickSizeProperty, value);
        }

        public static Size GetLargeTickSize(DependencyObject elem)
        {
            return (Size)elem.GetValue(LargeTickSizeProperty);
        }



        //大刻度画刷颜色
        public static readonly DependencyProperty LargeTickBrushProperty = DependencyProperty.RegisterAttached(
            "LargeTickBrush", typeof(Brush), typeof(RichTickBar),
            new FrameworkPropertyMetadata(Brushes.Black, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        public Brush LargeTickBrush
        {
            get { return (Brush)GetValue(LargeTickBrushProperty); }
            set { SetValue(LargeTickBrushProperty, value); }
        }

        public static void SetLargeTickBrush(DependencyObject elem, Brush value)
        {
            elem.SetValue(LargeTickBrushProperty, value);
        }

        public static Brush GetLargeTickBrush(DependencyObject elem)
        {
            return (Brush)elem.GetValue(LargeTickBrushProperty);
        }

        #endregion Large Ticks: Step, Radius, Alignment, Size, Brush




        // --------------------------------------------------------------------------------------------
        #region Text labels: Format & Brush

        public static readonly DependencyProperty TextFormatProperty = DependencyProperty.RegisterAttached(
            "TextFormat", typeof(string), typeof(RichTickBar),
            new FrameworkPropertyMetadata("{0:F0}", FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        [Category("Appearance")]
        public string TextFormat
        {
            get { return (string)GetValue(TextFormatProperty); }
            set { SetValue(TextFormatProperty, value); }
        }

        public static void SetTextFormat(DependencyObject elem, string value)
        {
            elem.SetValue(TextFormatProperty, value);
        }

        public static string GetTextFormat(DependencyObject elem)
        {
            return (string)elem.GetValue(TextFormatProperty);
        }





        public static readonly DependencyProperty TextBrushProperty = DependencyProperty.RegisterAttached(
            "TextBrush", typeof(Brush), typeof(RichTickBar),
            new FrameworkPropertyMetadata(Brushes.Black, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        public Brush TextBrush
        {
            get { return (Brush)GetValue(TextBrushProperty); }
            set { SetValue(TextBrushProperty, value); }
        }

        public static void SetTextBrush(DependencyObject elem, Brush value)
        {
            elem.SetValue(TextBrushProperty, value);
        }

        public static Brush GetTextBrush(DependencyObject elem)
        {
            return (Brush)elem.GetValue(TextBrushProperty);
        }



        //字号&距离
        public static readonly DependencyProperty TextSizeProperty = DependencyProperty.RegisterAttached(
            "LargeTextSize", typeof(double), typeof(RichTickBar),
            new FrameworkPropertyMetadata(10.0, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        public double LargeTextSize
        {
            get { return (double)GetValue(TextSizeProperty); }
            set { SetValue(TextSizeProperty, value); }
        }

        public static void SetTextSize(DependencyObject elem, double value)
        {
            elem.SetValue(TextSizeProperty, value);
        }

        public static double GetTextSize(DependencyObject elem)
        {
            return (double)elem.GetValue(TextSizeProperty);
        }
        #endregion Text labels: Format & Brush

    }
}
