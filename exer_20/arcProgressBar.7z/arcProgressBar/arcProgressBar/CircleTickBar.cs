﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Globalization;

namespace arcProgressBar
{
    public class CircleTickBar : RichTickBar
    {
        public CircleTickBar()
        {
        }

        #region Public Properties

        // --------------------------------------------------------------------------------------------
        #region 从x轴正方向开始计算偏移角度

        public static readonly DependencyProperty StartPositionProperty = DependencyProperty.RegisterAttached(
            "StartPosition", typeof(double), typeof(CircleTickBar),
           new FrameworkPropertyMetadata(135.0, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        //起始位置
        [Category("Appearance")]
        public double StartPosition
        {
            get { return (double)GetValue(StartPositionProperty); }
            set { SetValue(StartPositionProperty, value); }
        }

        public static void SetStartPosition(DependencyObject elem, double value)
        {
            elem.SetValue(StartPositionProperty, value);
        }

        public static double GetStartPosition(DependencyObject elem)
        {
            return (double)elem.GetValue(StartPositionProperty);
        }


        //结束位置
        public static readonly DependencyProperty EndPositionProperty = DependencyProperty.RegisterAttached(
            "EndPosition", typeof(double), typeof(CircleTickBar),
           new FrameworkPropertyMetadata(45.0, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        [Category("Appearance")]
        public double EndPosition
        {
            get { return (double)GetValue(EndPositionProperty); }
            set { SetValue(EndPositionProperty, value); }
        }

        public static void SetEndPosition(DependencyObject elem, double value)
        {
            elem.SetValue(EndPositionProperty, value);
        }

        public static double GetEndPosition(DependencyObject elem)
        {
            return (double)elem.GetValue(EndPositionProperty);
        }

        //当前值
        public static readonly DependencyProperty ValueProperty = DependencyProperty.RegisterAttached(
            "Value", typeof(double), typeof(CircleTickBar),
            new FrameworkPropertyMetadata(45.0, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        [Category("Appearance")]
        public double Value
        {
            get { return (double)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        public static void SetValue(DependencyObject elem, double value)
        {
            elem.SetValue(ValueProperty, value);
        }

        public static double GetValue(DependencyObject elem)
        {
            return (double)elem.GetValue(ValueProperty);
        }

        #endregion




        // --------------------------------------------------------------------------------------------
        // Thickness around the CircleTrack overlay this CircleTickBar.

        //public static readonly DependencyProperty PaddingProperty = DependencyProperty.Register(
        //   "Padding", typeof(Thickness), typeof(CircleTickBar),
        //   new FrameworkPropertyMetadata(new Thickness(0.0)));


        //public Thickness Padding
        //{
        //    get
        //    {
        //        return (Thickness)GetValue(PaddingProperty);
        //    }

        //    private set
        //    {
        //        SetValue(PaddingProperty, value);
        //    }
        //}


        #endregion Public Properties




        protected override Size MeasureOverride(Size constraint)
        {
            double radius = LargeTickSize.Height;

            GetTextHeight();

            radius += _textHeight;
            //Padding = new Thickness(radius*1.1);

            Size size = new Size(2 * radius, 2 * radius);

            return size;
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            if (finalSize.Width > finalSize.Height)
                _radius = finalSize.Height / 2;
            else
                _radius = finalSize.Width / 2;

            Size size = new Size(2*_radius, 2*_radius);

            return size;
        }

        protected override void OnRender(DrawingContext dc)
        {
            //-------------------------------------------------------------------------------------------------------
            //内部圆的半径
            double r = _radius - _textHeight - LargeTickSize.Height;

            double startPos = StartPosition;

            //将起始值输入转换至合法输入，将输入值控制在-180到180之间
            while (startPos < -180)
            {
                startPos += 360;
            }

            while (startPos >= 180)
            {
                startPos -= 360;
            }

            //将结束值输入转换至合法输入
            double endPos = EndPosition;
            while (endPos < startPos)
            {
                endPos += 360;
            }
            while (endPos >= startPos + 360)
            {
                endPos -= 360;
            }

            // -------------------------------------------------------------------------------------------------------
            //steps为小刻度数
            int steps = (int)((Maximum - Minimum) / SmallTickStep);
            double pos = startPos;
            _totalAngle = (endPos - startPos) * (steps * SmallTickStep / (Maximum - Minimum));
            //角度步长
            double stepAngle = _totalAngle / steps;
            Pen pen = new Pen(SmallTickBrush, SmallTickSize.Width);

            for (int i = 0; i <= steps; i++)
            {
                RotateTransform rt = new RotateTransform();
                //设置旋转中心为父容器的中心
                rt.CenterX = _radius;
                rt.CenterY = _radius;
                rt.Angle = pos + 90;

                dc.PushTransform(rt);
                //画中间的刻度线，并不断顺时针旋转（从起始位置的角度开始）
                dc.DrawLine(pen, new Point(_radius, _radius - r), new Point(_radius, _radius - r + (0.5*SmallTickSize.Height)));
                //dc.DrawLine(pen, new Point(30, _radius - r), new Point(_radius, _radius - r - SmallTickSize.Height));

                dc.Pop();

                pos += stepAngle;
            }

            // -------------------------------------------------------------------------------------------------------
            double value = Minimum;

            steps = (int)((Maximum - Minimum) / LargeTickStep);
            pos = startPos;
            _totalAngle = (endPos - startPos) * (steps * LargeTickStep / (Maximum - Minimum));
            stepAngle = _totalAngle / steps;
            pen = new Pen(LargeTickBrush, LargeTickSize.Width);

            for (int i = 0; i <= steps; i++)
            {
                //Rotates an object clockwise about a specified point in a 2-D x-y coordinate system.
                //顺时针旋转
                RotateTransform rt = new RotateTransform();
                //默认旋转中心为(0,0)，修改旋转中心
                rt.CenterX = _radius;
                rt.CenterY = _radius;
                rt.Angle = pos+90;

                dc.PushTransform(rt);
                
                
                //dc.DrawLine(pen, new Point(_radius,  _radius - r), new Point(_radius,  _radius - r - LargeTickSize.Height));
                dc.DrawLine(pen, new Point(_radius,  _radius - r), new Point(_radius,  _radius - r + LargeTickSize.Height));

                FormattedText textLabel;
                textLabel = new FormattedText(String.Format(TextFormat, value), CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, _typeface, LargeTextSize, TextBrush);
                textLabel.TextAlignment = TextAlignment.Center;
                //数字在内部
                dc.DrawText(textLabel, new Point(_radius, _radius - r + LargeTextSize));
                //数字在外部
                //dc.DrawText(textLabel, new Point(_radius,  _radius - r - LargeTickSize.Height - _textHeight));

                dc.Pop();
                //=====
                //画中心圆
                //Point centerPoint = new Point(_radius, _radius);
                //dc.DrawEllipse(null, new Pen(new SolidColorBrush(Colors.Black), 2), centerPoint, r, r);
                //====
                pos += stepAngle;
                value += LargeTickStep;
            }

            //根据当前值计算偏移角度
            DrawPointer(dc,r);
        }

        //获取文本高度
        private void GetTextHeight()
        {
            FontFamily fontFamily = (FontFamily)GetValue(TextElement.FontFamilyProperty);
            FontStyle fontStyle = (FontStyle)GetValue(TextElement.FontStyleProperty);
            FontWeight fontWeight = (FontWeight)GetValue(TextElement.FontWeightProperty);
            FontStretch fontStretch = (FontStretch)GetValue(TextElement.FontStretchProperty);
            //_fontSize = (double)GetValue(TextElement.FontSizeProperty);

            _typeface = new Typeface(fontFamily, fontStyle, fontWeight, fontStretch);
            FormattedText textLabel = new FormattedText(String.Format(TextFormat, Minimum), CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, _typeface, LargeTextSize, TextBrush);
            double height = textLabel.Height;

            _textHeight = height;
        }

        //根据当前值计算偏移角度
        private void DrawPointer(DrawingContext dc,double r)
        {
            double pos = StartPosition + Value*(_totalAngle/(Maximum-Minimum));

            //顺时针旋转
            RotateTransform rt = new RotateTransform();
            //默认选中中心为(0,0)，修改旋转中心
            rt.CenterX = _radius;
            rt.CenterY = _radius;
            rt.Angle = pos + 90;

            dc.PushTransform(rt);
            Brush pointerBrush = new SolidColorBrush(Colors.Red);

            Pen pen = new Pen(pointerBrush, SmallTickSize.Width);

            dc.DrawLine(pen, new Point(_radius, _radius), new Point(_radius, _radius - r));
            dc.Pop();
        }

        private double _radius;
        private Typeface _typeface;
        //private double _fontSize;
        private double _textHeight;

        private double _totalAngle;
    }
}
