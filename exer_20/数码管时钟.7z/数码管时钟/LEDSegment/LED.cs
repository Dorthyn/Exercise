﻿using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;

namespace LEDSegment
{
    class Led : FrameworkElement
    {
        public Led()
        {

        }
        #region DP


        public double Length
        {
            get { return (double)GetValue(LengthProperty); }
            set { SetValue(LengthProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Length.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LengthProperty =
            DependencyProperty.Register("Length", typeof(double), typeof(Led), new PropertyMetadata(10.0));



        public int Value
        {
            get { return (int)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Value.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(int), typeof(Led), new PropertyMetadata(-1,new PropertyChangedCallback(OnValueChanged)));



        #endregion
        protected override Size MeasureOverride(Size constraint)
        {
            //灯管长度
            double bulbWidth = Length;
            Size size = new Size(3 * bulbWidth, 4 * bulbWidth);

            return size;
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            //灯管长度
            double bulbWidth = Length;
            Size size = new Size(3 * bulbWidth, 4 * bulbWidth);
            return size;
        }

        private static void OnValueChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {

        }

        protected override void OnRender(DrawingContext dc)
        {
            double pos = Length;
            Pen pen = new Pen(Brushes.Red, 2);
            
            //根据当前Value值画当前的数值
            switch (Value)
            {
                case 0:
                    //abcdef
                {
                    //a
                    dc.DrawLine(pen, new Point(pos, pos), new Point(pos, 2 * pos));
                    //b
                    dc.DrawLine(pen, new Point(pos, pos), new Point(2 * pos, pos));
                    //c
                    dc.DrawLine(pen, new Point(2 * pos, pos), new Point(2 * pos, 2 * pos));
                    //d
                    dc.DrawLine(pen, new Point(2 * pos, 2 * pos), new Point(2 * pos, 3 * pos));
                    //e
                    dc.DrawLine(pen, new Point(pos, 3 * pos), new Point(2 * pos, 3 * pos));
                    //f
                    dc.DrawLine(pen, new Point(pos, 2 * pos), new Point(pos, 3 * pos));
                    }
                    break;
                case 1:
                    //cd
                {
                    //c
                    dc.DrawLine(pen, new Point(2 * pos, pos), new Point(2 * pos, 2 * pos));
                    //d
                    dc.DrawLine(pen, new Point(2 * pos, 2 * pos), new Point(2 * pos, 3 * pos));
                    }
                    break;
                case 2:
                    //
                {
                    //b
                    dc.DrawLine(pen, new Point(pos, pos), new Point(2 * pos, pos));
                    //c
                    dc.DrawLine(pen, new Point(2 * pos, pos), new Point(2 * pos, 2 * pos));
                    //e
                    dc.DrawLine(pen, new Point(pos, 3 * pos), new Point(2 * pos, 3 * pos));
                    //f
                    dc.DrawLine(pen, new Point(pos, 2 * pos), new Point(pos, 3 * pos));
                    //g
                    dc.DrawLine(pen, new Point(pos, 2 * pos), new Point(2 * pos, 2 * pos));
                    }
                    break;
                case 3:
                {
                    //b
                    dc.DrawLine(pen, new Point(pos, pos), new Point(2 * pos, pos));
                    //c
                    dc.DrawLine(pen, new Point(2 * pos, pos), new Point(2 * pos, 2 * pos));
                    //d
                    dc.DrawLine(pen, new Point(2 * pos, 2 * pos), new Point(2 * pos, 3 * pos));
                    //e
                    dc.DrawLine(pen, new Point(pos, 3 * pos), new Point(2 * pos, 3 * pos));
                    //g
                    dc.DrawLine(pen, new Point(pos, 2 * pos), new Point(2 * pos, 2 * pos));
                    }
                    break;
                case 4:
                {
                    //a
                    dc.DrawLine(pen, new Point(pos, pos), new Point(pos, 2 * pos));
                    //c
                    dc.DrawLine(pen, new Point(2 * pos, pos), new Point(2 * pos, 2 * pos));
                    //d
                    dc.DrawLine(pen, new Point(2 * pos, 2 * pos), new Point(2 * pos, 3 * pos));
                    //g
                    dc.DrawLine(pen, new Point(pos, 2 * pos), new Point(2 * pos, 2 * pos));
                    }
                    break;
                case 5:
                {
                    //a
                    dc.DrawLine(pen, new Point(pos, pos), new Point(pos, 2 * pos));
                    //b
                    dc.DrawLine(pen, new Point(pos, pos), new Point(2 * pos, pos));
                    //d
                    dc.DrawLine(pen, new Point(2 * pos, 2 * pos), new Point(2 * pos, 3 * pos));
                    //e
                    dc.DrawLine(pen, new Point(pos, 3 * pos), new Point(2 * pos, 3 * pos));
                    //g
                    dc.DrawLine(pen, new Point(pos, 2 * pos), new Point(2 * pos, 2 * pos));
                    }
                    break;
                case 6:
                {
                    //a
                    dc.DrawLine(pen, new Point(pos, pos), new Point(pos, 2 * pos));
                    //b
                    dc.DrawLine(pen, new Point(pos, pos), new Point(2 * pos, pos));
                    //d
                    dc.DrawLine(pen, new Point(2 * pos, 2 * pos), new Point(2 * pos, 3 * pos));
                    //e
                    dc.DrawLine(pen, new Point(pos, 3 * pos), new Point(2 * pos, 3 * pos));
                    //f
                    dc.DrawLine(pen, new Point(pos, 2 * pos), new Point(pos, 3 * pos));
                    //g
                    dc.DrawLine(pen, new Point(pos, 2 * pos), new Point(2 * pos, 2 * pos));
                    }
                    break;
                case 7:
                {
                    //b
                    dc.DrawLine(pen, new Point(pos, pos), new Point(2 * pos, pos));
                    //c
                    dc.DrawLine(pen, new Point(2 * pos, pos), new Point(2 * pos, 2 * pos));
                    //d
                    dc.DrawLine(pen, new Point(2 * pos, 2 * pos), new Point(2 * pos, 3 * pos));
                    }
                    break;
                case 8:
                {
                    //a
                    dc.DrawLine(pen, new Point(pos, pos), new Point(pos, 2 * pos));
                    //b
                    dc.DrawLine(pen, new Point(pos, pos), new Point(2 * pos, pos));
                    //c
                    dc.DrawLine(pen, new Point(2 * pos, pos), new Point(2 * pos, 2 * pos));
                    //d
                    dc.DrawLine(pen, new Point(2 * pos, 2 * pos), new Point(2 * pos, 3 * pos));
                    //e
                    dc.DrawLine(pen, new Point(pos, 3 * pos), new Point(2 * pos, 3 * pos));
                    //f
                    dc.DrawLine(pen, new Point(pos, 2 * pos), new Point(pos, 3 * pos));
                    //g
                    dc.DrawLine(pen, new Point(pos, 2 * pos), new Point(2 * pos, 2 * pos));
                    }
                    break;
                case 9:
                {
                    //a
                    dc.DrawLine(pen, new Point(pos, pos), new Point(pos, 2 * pos));
                    //b
                    dc.DrawLine(pen, new Point(pos, pos), new Point(2 * pos, pos));
                    //c
                    dc.DrawLine(pen, new Point(2 * pos, pos), new Point(2 * pos, 2 * pos));
                    //d
                    dc.DrawLine(pen, new Point(2 * pos, 2 * pos), new Point(2 * pos, 3 * pos));
                    //e
                    dc.DrawLine(pen, new Point(pos, 3 * pos), new Point(2 * pos, 3 * pos));
                    //g
                    dc.DrawLine(pen, new Point(pos, 2 * pos), new Point(2 * pos, 2 * pos));
                    }
                    break;
                case -2:
                {
                    dc.DrawLine(pen, new Point(pos*1.5, (4.0/3) * pos), new Point(1.5 * pos, (5.0 / 3) * pos));
                    dc.DrawLine(pen, new Point(pos*1.5, (7.0/3) * pos), new Point(1.5 * pos, (8.0 / 3) * pos));
                    }
                    break;
                default:break;
            }
        }
    }
}
