﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace LEDSegment
{
    /// <summary>
    /// Interaction logic for Numbers.xaml
    /// </summary>
    public partial class Numbers : UserControl
    {
        #region DP


        public int Value
        {
            get { return (int)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MyProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(int), typeof(Numbers), new PropertyMetadata(-1));



        public bool DecimalShow
        {
            get { return (bool)GetValue(DecimalShowProperty); }
            set { SetValue(DecimalShowProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DecimalShow.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DecimalShowProperty =
            DependencyProperty.Register("DecimalShow", typeof(bool), typeof(Numbers), new PropertyMetadata(false));



        #endregion

        public Numbers()
        {
            InitializeComponent();
            //ShowNumber(Value);
        }
        //中间的线为a，顺时针走一圈分别为b-g
        protected override void OnRender(DrawingContext dc)
        {
            var a = new Unit_1();
            a.Width = 45;
            a.Height = 10;

            //b
            var b = new Unit_1();
            b.Width = 45;
            b.Height = 10;

            b.RenderTransformOrigin = new Point(0.11, 0.5);
            RotateTransform mRotateTransform = new RotateTransform();
            mRotateTransform.Angle = -90;

            TransformGroup mTransformGroup = new TransformGroup();
            mTransformGroup.Children.Add(mRotateTransform);
            b.RenderTransform = mTransformGroup;
            //=======
            //c
            var c = new Unit_1();
            c.Width = 45;
            c.Height = 10;

            c.RenderTransformOrigin = new Point(0.5, -1.3);
            mRotateTransform = new RotateTransform();
            mRotateTransform.Angle = 180;

            mTransformGroup = new TransformGroup();
            mTransformGroup.Children.Add(mRotateTransform);
            c.RenderTransform = mTransformGroup;

            //d
            var d = new Unit_1();
            d.Width = 45;
            d.Height = 10;

            d.RenderTransformOrigin = new Point(0.89, 0.5);
            mRotateTransform = new RotateTransform();
            mRotateTransform.Angle = 90;

            mTransformGroup = new TransformGroup();
            mTransformGroup.Children.Add(mRotateTransform);
            d.RenderTransform = mTransformGroup;

            //e
            var e = new Unit_1();
            e.Width = 45;
            e.Height = 10;

            e.RenderTransformOrigin = new Point(0.89, 0.5);
            mRotateTransform = new RotateTransform();
            mRotateTransform.Angle = -90;

            mTransformGroup = new TransformGroup();
            mTransformGroup.Children.Add(mRotateTransform);
            e.RenderTransform = mTransformGroup;

            //f
            var f = new Unit_1();
            f.Width = 45;
            f.Height = 10;

            f.RenderTransformOrigin = new Point(0.5, 2.3);
            mRotateTransform = new RotateTransform();
            mRotateTransform.Angle = 180;

            mTransformGroup = new TransformGroup();
            mTransformGroup.Children.Add(mRotateTransform);
            f.RenderTransform = mTransformGroup;
            //g
            var g = new Unit_1();
            g.Width = 45;
            g.Height = 10;

            g.RenderTransformOrigin = new Point(0.11, 0.5);
            mRotateTransform = new RotateTransform();
            mRotateTransform.Angle = 90;

            mTransformGroup = new TransformGroup();
            mTransformGroup.Children.Add(mRotateTransform);
            g.RenderTransform = mTransformGroup;

            Pen myPen = new Pen(Brushes.Gray, 1);
            switch (Value)
            {
                case 0:
                    //清除残留
                    Grid.Children.Clear();
                    //添加到Grid中
                    //Grid.Children.Add(a);
                    Grid.Children.Add(b);
                    Grid.Children.Add(c);
                    Grid.Children.Add(d);
                    Grid.Children.Add(e);
                    Grid.Children.Add(f);
                    Grid.Children.Add(g);
                    break;
                case 1:
                    //清除残留
                    Grid.Children.Clear();

                    Grid.Children.Add(d);
                    Grid.Children.Add(e);
                    break;
                case 2:
                    //清除残留
                    Grid.Children.Clear();

                    Grid.Children.Add(a);
                    Grid.Children.Add(c);
                    Grid.Children.Add(d);
                    Grid.Children.Add(f);
                    Grid.Children.Add(g);
                    break;
                case 3:
                    //清除残留
                    Grid.Children.Clear();

                    Grid.Children.Add(a);
                    Grid.Children.Add(c);
                    Grid.Children.Add(d);
                    Grid.Children.Add(e);
                    Grid.Children.Add(f);
                    break;
                case 4:
                    //清除残留
                    Grid.Children.Clear();

                    Grid.Children.Add(a);
                    Grid.Children.Add(b);
                    Grid.Children.Add(d);
                    Grid.Children.Add(e);
                    break;
                case 5:
                    //清除残留
                    Grid.Children.Clear();

                    Grid.Children.Add(a);
                    Grid.Children.Add(b);
                    Grid.Children.Add(c);
                    Grid.Children.Add(e);
                    Grid.Children.Add(f);
                    break;
                case 6:
                    //清除残留
                    Grid.Children.Clear();

                    Grid.Children.Add(a);
                    Grid.Children.Add(b);
                    Grid.Children.Add(c);
                    Grid.Children.Add(e);
                    Grid.Children.Add(f);
                    Grid.Children.Add(g);
                    break;
                case 7:
                    //清除残留
                    Grid.Children.Clear();

                    Grid.Children.Add(c);
                    Grid.Children.Add(d);
                    Grid.Children.Add(e);
                    break;
                case 8:
                    //清除残留
                    Grid.Children.Clear();

                    Grid.Children.Add(a);
                    Grid.Children.Add(b);
                    Grid.Children.Add(c);
                    Grid.Children.Add(d);
                    Grid.Children.Add(e);
                    Grid.Children.Add(f);
                    Grid.Children.Add(g);
                    break;
                case 9:
                    //清除残留
                    Grid.Children.Clear();

                    Grid.Children.Add(a);
                    Grid.Children.Add(b);
                    Grid.Children.Add(c);
                    Grid.Children.Add(d);
                    Grid.Children.Add(e);
                    Grid.Children.Add(f);
                    break;
                case -2:
                    //冒号
                    dc.DrawRectangle(new SolidColorBrush(Colors.Red),myPen,new Rect(20,20,10,10) );
                    dc.DrawRectangle(new SolidColorBrush(Colors.Red),myPen,new Rect(20,60,10,10) );
                    break;
                case -3:
                    //撇
                    dc.DrawRectangle(new SolidColorBrush(Colors.Red), myPen, new Rect(45, 0, 5, 5));
                    break;
                default:break;
            }

            if (DecimalShow)
            {
                //点
                dc.DrawRectangle(new SolidColorBrush(Colors.Red), myPen, new Rect(45, 85, 5, 5));
            }

        }
    }
}
