﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace LEDSegment
{
    /// <summary>
    /// Interaction logic for DigitalClock.xaml
    /// </summary>
    public partial class DigitalClock : UserControl
    {
        public DigitalClock()
        {
            InitializeComponent();
            DispatcherTimer dispatcherTimer = new DispatcherTimer();
            dispatcherTimer.Tick += dispatcherTimer_Tick;
            dispatcherTimer.Interval = new TimeSpan(0, 0, 1);
            dispatcherTimer.Start();
        }

        private void dispatcherTimer_Tick(object sender, EventArgs e)
        {
            // 时
            int hour = Convert.ToInt16(DateTime.Now.ToString("HH"));
            //提取十位数
            A.Value = hour / 10;

            B.Value = hour % 10;
            //分
            int minute = Convert.ToInt16(DateTime.Now.ToString("mm"));
            D.Value = minute / 10;
            E.Value = minute % 10;
            //秒
            int second = Convert.ToInt16(DateTime.Now.ToString("ss"));
            G.Value = second / 10;
            H.Value = second % 10;

            A.InvalidateVisual();
            B.InvalidateVisual();
            D.InvalidateVisual();
            E.InvalidateVisual();
            G.InvalidateVisual();
            H.InvalidateVisual();

        }
    }
}
