﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TemperatureProgressBar
{
	public partial class LabelProgressBar : RangeBase
	{
        #region Public Properties

        // --------------------------------------------------------------------------------------------
        #region Orientation & TickPlacement

        public static readonly DependencyProperty OrientationProperty = ProgressBar.OrientationProperty.AddOwner(
            typeof(LabelProgressBar));

        [Category("Appearance")]
        public Orientation Orientation
        {
            get { return (Orientation)GetValue(OrientationProperty); }
            set { SetValue(OrientationProperty, value); }
        }



        public static readonly DependencyProperty TickPlacementProperty = LabelTickBar.TickPlacementProperty.AddOwner(typeof(LabelProgressBar), 
           new FrameworkPropertyMetadata(TickPlacement.TopLeft, FrameworkPropertyMetadataOptions.None,
                null, TickPlacementCoerceValueCallback));

        // override LabelTickBar's CoerceValueCallback, which does not accept 'Both' & 'None'.
        public static Object TickPlacementCoerceValueCallback(DependencyObject d, Object baseValue)
        {
            TickPlacement tickPlacement = (TickPlacement)baseValue;

            return tickPlacement;
        }

        [Category("Appearance")]
        public TickPlacement TickPlacement
        {
            get { return (TickPlacement)GetValue(TickPlacementProperty); }
            set { SetValue(TickPlacementProperty, value); }
        }

        #endregion Orientation & TickPlacement



        #endregion Public Properties

    }
}