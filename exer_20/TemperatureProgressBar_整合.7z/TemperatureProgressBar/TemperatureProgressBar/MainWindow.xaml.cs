﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml;

namespace TemperatureProgressBar
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }

        [ValueConversion(typeof(bool), typeof(Visibility))]
        public class Boolean2VisibilityConverter : IValueConverter
        {
            public Object Convert(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                Visibility visibility = ((bool) value) ? Visibility.Visible : Visibility.Hidden;

                return visibility;
            }

            public Object ConvertBack(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                throw new NotSupportedException();
            }
        }

        [ValueConversion(typeof(double), typeof(double))]
        public class AddConverter : IValueConverter
        {
            public Object Convert(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                double num = (double) value;
                double num2 = double.Parse(parameter.ToString());

                num += num2;

                return num;
            }

            public Object ConvertBack(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                throw new NotSupportedException();
            }
        }

        [ValueConversion(typeof(double), typeof(double))]
        public class MinusConverter : IValueConverter
        {
            public Object Convert(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                double num = (double) value;
                double num2 = double.Parse(parameter.ToString());

                num -= num2;

                return num;
            }

            public Object ConvertBack(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                throw new NotSupportedException();
            }
        }

        [ValueConversion(typeof(double), typeof(double))]
        public class MultiplyConverter : IValueConverter
        {
            public Object Convert(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                double num = (double) value;
                double num2 = double.Parse(parameter.ToString());

                num *= num2;

                return num;
            }

            public Object ConvertBack(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                throw new NotSupportedException();
            }
        }

        [ValueConversion(typeof(double), typeof(double))]
        public class DivideConverter : IValueConverter
        {
            public Object Convert(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                double num = (double) value;
                double num2 = double.Parse(parameter.ToString());

                num /= num2;

                return num;
            }

            public Object ConvertBack(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                throw new NotSupportedException();
            }
        }

        [ValueConversion(typeof(double), typeof(string))]
        public class Double2StringConverter : IValueConverter
        {
            public Object Convert(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                double num = (double) value;
                string format = (string) parameter;

                string str = String.Format(format, num);

                return str;
            }

            public Object ConvertBack(Object value, Type targetType, Object parameter, CultureInfo cultureInfo)
            {
                throw new NotSupportedException();
            }
        }
    }
}
