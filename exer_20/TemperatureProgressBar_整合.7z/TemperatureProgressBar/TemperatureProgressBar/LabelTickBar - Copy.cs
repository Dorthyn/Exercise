﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Globalization;

namespace TemperatureProgressBar
{
    public partial class LabelTickBar : RichTickBar
    {
        
        public LabelTickBar()
        {
            scaleFontSize = 1.75;
        }


        #region Public Properties

        // --------------------------------------------------------------------------------------------
        #region Orientation & TickPlacement

        public static readonly DependencyProperty OrientationProperty = DependencyProperty.RegisterAttached(
            "Orientation", typeof(Orientation), typeof(LabelTickBar),
           new FrameworkPropertyMetadata(Orientation.Horizontal, FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsRender));

        [Category("Appearance")]
        public Orientation Orientation
        {
            get { return (Orientation)GetValue(OrientationProperty); }
            set { SetValue(OrientationProperty, value); }
        }

        public static void SetOrientation(DependencyObject elem, Orientation value)
        {
            elem.SetValue(OrientationProperty, value);
        }

        public static Orientation GetOrientation(DependencyObject elem)
        {
            return (Orientation)elem.GetValue(OrientationProperty);
        }




        public static readonly DependencyProperty TickPlacementProperty = DependencyProperty.RegisterAttached(
            "TickPlacement", typeof(TickPlacement), typeof(LabelTickBar),
           new FrameworkPropertyMetadata(TickPlacement.TopLeft, FrameworkPropertyMetadataOptions.AffectsRender,
                null, TickPlacementCoerceValueCallback));

        public static Object TickPlacementCoerceValueCallback(DependencyObject d, Object baseValue)
        {
            TickPlacement tickPlacement = (TickPlacement)baseValue;

            if (tickPlacement != TickPlacement.TopLeft && tickPlacement != TickPlacement.BottomRight)
            {
                tickPlacement = TickPlacement.TopLeft;
            }

            return tickPlacement;
        }

        [Category("Appearance")]
        public TickPlacement TickPlacement
        {
            get { return (TickPlacement)GetValue(TickPlacementProperty); }
            set { SetValue(TickPlacementProperty, value); }
        }

        public static void SetTickPlacement(DependencyObject elem, TickPlacement value)
        {
            elem.SetValue(TickPlacementProperty, value);
        }

        public static TickPlacement GetTickPlacement(DependencyObject elem)
        {
            return (TickPlacement)elem.GetValue(TickPlacementProperty);
        }

        #endregion Orientation & TickPlacement




        // --------------------------------------------------------------------------------------------
        // Text Alignment

        public static readonly DependencyProperty TextAlignmentProperty = DependencyProperty.RegisterAttached(
            "TextAlignment", typeof(TextAlignment), typeof(LabelTickBar),
           new FrameworkPropertyMetadata(TextAlignment.Center, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.Inherits));

        [Category("Appearance")]
        public TextAlignment TextAlignment
        {
            get { return (TextAlignment)GetValue(TextAlignmentProperty); }
            set { SetValue(TextAlignmentProperty, value); }
        }

        public static void SetTextAlignment(DependencyObject elem, TextAlignment value)
        {
            elem.SetValue(TextAlignmentProperty, value);
        }

        public static TextAlignment GetTextAlignment(DependencyObject elem)
        {
            return (TextAlignment)elem.GetValue(TextAlignmentProperty);
        }




        #endregion Public Properties




        protected override Size MeasureOverride(Size constraint)
        {
            Size size = new Size();

            GetTextSize();

            if (Orientation == Orientation.Horizontal)
            {
                if (Double.IsPositiveInfinity(constraint.Width))
                    size.Width = 0;
                else
                    size.Width = constraint.Width;

                size.Height = LargeTickSize.Height + _largeTextSize.Height;
            }
            else
            {
                if (Double.IsPositiveInfinity(constraint.Height))
                    size.Height = 0;
                else
                    size.Height = constraint.Height;

                size.Width = LargeTickSize.Height + _largeTextSize.Width;
            }

            return size;
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            _rect = new Rect(finalSize);

            return finalSize;
        }

        protected override void OnRender(DrawingContext dc)
        {
            //dc.DrawRectangle(null, new Pen(Brushes.Red, 1), _rect);

            //-------------------------------------------------------------------------------------------------------
            //steps为大刻度数量
            //textLabel用于显示刻度值
            FormattedText textLabel;

            int steps = (int)((Maximum - Minimum) / SmallTickStep);
            double width;
            double pos;
            double stepWidth;
            Pen pen = new Pen(SmallTickBrush, SmallTickSize.Width);
            //textPos为文本位置
            double textPos;
            double start, end;
            double value = Minimum;
            //画刻度时判断朝向
            //横向时
            if (Orientation == Orientation.Horizontal)
            {
                width = _rect.Width * (steps * SmallTickStep / (Maximum - Minimum));
                stepWidth = width / steps;
                pos = 0;

                if (TickPlacement == TickPlacement.TopLeft)
                {
                    start = _rect.Height;
                    end = _rect.Height - SmallTickSize.Height;
                    textPos = _rect.Height - SmallTickSize.Height - _smallTextSize.Height;
                }
                else
                {
                    start = 0;
                    end = SmallTickSize.Height;
                    textPos = SmallTickSize.Height;
                }

                for (int i = 0; i <= steps; i++)
                {
                    dc.DrawLine(pen, new Point(pos, start), new Point(pos, end));
                    textLabel = new FormattedText(String.Format(TextFormat, value), CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, _typeface, LargeTextSize/scaleFontSize, TextBrush);
                    textLabel.TextAlignment = TextAlignment;
                    if (!(Math.Abs(value % LargeTickStep) < 0.001))
                    {
                        dc.DrawText(textLabel, new Point(pos, textPos));
                    }

                    pos += stepWidth;
                    value += SmallTickStep;
                }
            }
            else
            {
                width = _rect.Height * (steps * SmallTickStep / (Maximum - Minimum));
                stepWidth = width / steps;
                pos = _rect.Height;

                if (TickPlacement == TickPlacement.TopLeft)
                {
                    start = _rect.Width;
                    end = _rect.Width - SmallTickSize.Height;

                    if (TextAlignment == TextAlignment.Left)
                    {
                        textPos = _rect.Width - SmallTickSize.Height - _smallTextSize.Width;
                    }
                    else if (TextAlignment == TextAlignment.Center)
                    {
                        textPos = _rect.Width - SmallTickSize.Height - _smallTextSize.Width / 2;
                    }
                    else // TextAlignment.Right
                    {
                        textPos = _rect.Width - SmallTickSize.Height;
                    }
                }
                else
                {
                    start = 0;
                    end = SmallTickSize.Height;

                    if (TextAlignment == TextAlignment.Right)
                    {
                        textPos = SmallTickSize.Height + _smallTextSize.Width;
                    }
                    else if (TextAlignment == TextAlignment.Center)
                    {
                        textPos = SmallTickSize.Height + _smallTextSize.Width / 2;
                    }
                    else // TextAlignment.Left
                    {
                        textPos = SmallTickSize.Height;
                    }
                }

                for (int i = 0; i <= steps; i++)
                {
                    dc.DrawLine(pen, new Point(start, pos), new Point(end, pos));

                    textLabel = new FormattedText(String.Format(TextFormat, value), CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, _typeface, LargeTextSize/scaleFontSize, TextBrush);
                    textLabel.TextAlignment = TextAlignment;
                    if (!(Math.Abs(value % LargeTickStep) < 0.001))
                    {
                        dc.DrawText(textLabel, new Point(textPos, pos - _smallTextSize.Height / 2));
                    }

                    pos -= stepWidth;
                    value += SmallTickStep;
                }
            }


            // -------------------------------------------------------------------------------------------------------
            //FormattedText textLabel;

            steps = (int)((Maximum - Minimum) / LargeTickStep);

            pen = new Pen(LargeTickBrush, LargeTickSize.Width);
            value = Minimum;
            //double textPos;

            if (Orientation == Orientation.Horizontal)
            {
                width = _rect.Width * (steps * LargeTickStep / (Maximum - Minimum));
                stepWidth = width / steps;
                pos = 0;

                if (TickPlacement == TickPlacement.TopLeft)
                {
                    start = _rect.Height;
                    end = _rect.Height - LargeTickSize.Height;
                    textPos = _rect.Height - LargeTickSize.Height - _largeTextSize.Height;
                }
                else
                {
                    start = 0;
                    end = LargeTickSize.Height;
                    textPos = LargeTickSize.Height;
                }

                for (int i = 0; i <= steps; i++)
                {
                    dc.DrawLine(pen, new Point(pos,start), new Point(pos, end));

                    textLabel = new FormattedText(String.Format(TextFormat, value), CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, _typeface, LargeTextSize, TextBrush);
                    textLabel.TextAlignment = TextAlignment;
                    dc.DrawText(textLabel, new Point(pos, textPos));

                    pos += stepWidth;
                    value += LargeTickStep;
                }
            }
            else
            {
                width = _rect.Height * (steps * LargeTickStep / (Maximum - Minimum));
                stepWidth = width / steps;
                pos = _rect.Height;

                if (TickPlacement == TickPlacement.TopLeft)
                {
                    start = _rect.Width;
                    end = _rect.Width - LargeTickSize.Height;

                    if (TextAlignment == TextAlignment.Left)
                    {
                        textPos = _rect.Width - LargeTickSize.Height - _largeTextSize.Width;
                    }
                    else if (TextAlignment == TextAlignment.Center)
                    {
                        textPos = _rect.Width - LargeTickSize.Height - _largeTextSize.Width / 2;
                    }
                    else // TextAlignment.Right
                    {
                        textPos = _rect.Width - LargeTickSize.Height;
                    }
                }
                else
                {
                    start = 0;
                    end = LargeTickSize.Height;

                    if (TextAlignment == TextAlignment.Right)
                    {
                        textPos = LargeTickSize.Height + _largeTextSize.Width;
                    }
                    else if (TextAlignment == TextAlignment.Center)
                    {
                        textPos = LargeTickSize.Height + _largeTextSize.Width / 2;
                    }
                    else // TextAlignment.Left
                    {
                        textPos = LargeTickSize.Height;
                    }
                }

                for (int i = 0; i <= steps; i++)
                {
                    dc.DrawLine(pen, new Point(start, pos), new Point(end, pos));

                    textLabel = new FormattedText(String.Format(TextFormat, value), CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, _typeface, LargeTextSize, TextBrush);
                    textLabel.TextAlignment = TextAlignment;
                    dc.DrawText(textLabel, new Point(textPos, pos - _largeTextSize.Height / 2));

                    pos -= stepWidth;
                    value += LargeTickStep;
                }
            }

        }

        private void GetTextSize()
        {
            FontFamily fontFamily = (FontFamily)GetValue(TextElement.FontFamilyProperty);
            FontStyle fontStyle = (FontStyle)GetValue(TextElement.FontStyleProperty);
            FontWeight fontWeight = (FontWeight)GetValue(TextElement.FontWeightProperty);
            FontStretch fontStretch = (FontStretch)GetValue(TextElement.FontStretchProperty);
            _fontSize = (double)GetValue(TextElement.FontSizeProperty);

            _typeface = new Typeface(fontFamily, fontStyle, fontWeight, fontStretch);

            FormattedText textLabel = new FormattedText(String.Format(TextFormat, Minimum), CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, _typeface, LargeTextSize, TextBrush);
            double width = textLabel.BuildGeometry(new Point()).Bounds.Width;

            textLabel = new FormattedText(String.Format(TextFormat, Maximum), CultureInfo.CurrentUICulture, FlowDirection.LeftToRight, _typeface, LargeTextSize, TextBrush);
            double width2 = textLabel.BuildGeometry(new Point()).Bounds.Width;

            width = (width2 > width) ? width2 : width;

            double height = textLabel.Height;

            _largeTextSize = new Size(width, height);
            _smallTextSize = new Size(width, height/scaleFontSize);
        }

        private Rect _rect;
        private Typeface _typeface;
        private double _fontSize;
        private Size _largeTextSize;
        private Size _smallTextSize;
        private static double scaleFontSize;
    }
}
