﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace keyboardImation
{
    class KeysData:INotifyPropertyChanged
    {
        public KeysData()
        {
            TopKeys = EngTopKeys;
            MiddleKeys = EngMiddleKeys;
            BottomKeys = EngBottomKeys;
            CurrentLang = LanguageState.Eng;
        }

        public enum LanguageState
        {
            Eng,
            Rus
        }

        public ObservableCollection<String> NumberKeys
        {
            get
            {
                return new ObservableCollection<String>()
                {
                    "1",
                    "2",
                    "3",
                    "4",
                    "5",
                    "6",
                    "7",
                    "8",
                    "9",
                    "0",
                };
            }
        }

        public ObservableCollection<KeyModel> EngTopKeys
        {
            get
            {
                return new ObservableCollection<KeyModel>()
                {
                    new KeyModel("q"),
                    new KeyModel("w"),
                    new KeyModel("e"),
                    new KeyModel("r"),
                    new KeyModel("t"),
                    new KeyModel("y"),
                    new KeyModel("u"),
                    new KeyModel("i"),
                    new KeyModel("o"),
                    new KeyModel("p"),
                };
                    
            }
        }

        public ObservableCollection<KeyModel> EngMiddleKeys
        {
            get
            {
                return new ObservableCollection<KeyModel>()
                {
                    new KeyModel("a"),
                    new KeyModel("s"),
                    new KeyModel("d"),
                    new KeyModel("f"),
                    new KeyModel("g"),
                    new KeyModel("h"),
                    new KeyModel("j"),
                    new KeyModel("k"),
                    new KeyModel("l"),
                };
            }
        }

        public ObservableCollection<KeyModel> EngBottomKeys
        {
            get
            {
                return new ObservableCollection<KeyModel>()
                {
                    new KeyModel("z"),
                    new KeyModel("x"),
                    new KeyModel("c"),
                    new KeyModel("v"),
                    new KeyModel("b"),
                    new KeyModel("n"),
                    new KeyModel("m"),
                };
            }
        }

        public ObservableCollection<KeyModel> RusTopKeys
        {
            get
            {
                return new ObservableCollection<KeyModel>()
                {
                    new KeyModel("й"),
                    new KeyModel("ц"),
                    new KeyModel("у"),
                    new KeyModel("к"),
                    new KeyModel("е"),
                    new KeyModel("н"),
                    new KeyModel("г"),
                    new KeyModel("ш"),
                    new KeyModel("щ"),
                    new KeyModel("з"),
                    new KeyModel("х"),
                    new KeyModel("ъ")
                };
            }
        }

        public ObservableCollection<KeyModel> RusMiddleKeys
        {
            get
            {
                return new ObservableCollection<KeyModel>()
                {
                    new KeyModel("ф"),
                    new KeyModel("ы"),
                    new KeyModel("в"),
                    new KeyModel("а"),
                    new KeyModel("п"),
                    new KeyModel("р"),
                    new KeyModel("о"),
                    new KeyModel("л"),
                    new KeyModel("д"),
                    new KeyModel("ж"),
                    new KeyModel("э")
                };
            }
        }

        public ObservableCollection<KeyModel> RusBottomKeys
        {
            get
            {
                return new ObservableCollection<KeyModel>()
                {
                    new KeyModel("я"),
                    new KeyModel("ч"),
                    new KeyModel("с"),
                    new KeyModel("м"),
                    new KeyModel("и"),
                    new KeyModel("т"),
                    new KeyModel("ь"),
                    new KeyModel("б"),
                    new KeyModel("ю")
                };
            }
        }

        private ObservableCollection<KeyModel> _TopKeys;
        public ObservableCollection<KeyModel> TopKeys
        {
            get { return _TopKeys; }
            set { _TopKeys = value; DoPropertyChanged("TopKeys"); }
        }

        //public ObservableCollection<KeyModel> TopKeys
        //{
        //    get { return _TopKeys; }
        //    set { _TopKeys = value; DoPropertyChanged("TopKeys"); }
        //}

        private ObservableCollection<KeyModel> _MiddleKeys;
        public ObservableCollection<KeyModel> MiddleKeys
        {
            get { return _MiddleKeys; }
            set { _MiddleKeys = value; DoPropertyChanged("MiddleKeys"); }
        }

        private ObservableCollection<KeyModel> _BottomKeys;
        public ObservableCollection<KeyModel> BottomKeys
        {
            get { return _BottomKeys; }
            set { _BottomKeys = value; DoPropertyChanged("BottomKeys"); }
        }

        //当前语种
        private LanguageState _currentLang;

        public LanguageState CurrentLang
        {
            get { return _currentLang; }
            set { _currentLang = value;DoPropertyChanged("CurrentLang"); }
        }

        private void LanguageFlag()
        {
            if (CurrentLang == LanguageState.Eng)
            {
                CurrentLang = LanguageState.Rus;
            }
            else
            {
                CurrentLang = LanguageState.Eng;
            }
        }

        //属性发生变化，则通知
        public Boolean ShiftFlag
        {
            get;
            set;
        }

        //public Boolean ShiftFlag
        //{
        //    get { return _shiftFlag; }
        //    set { _shiftFlag = value; DoPropertyChanged("ShiftFlag"); }
        //}

        //判断当前Shift的状态
        private void ToggleFlag()
        {
            ShiftFlag = !ShiftFlag;
        }

        private Command _shiftCommand;
        public Command ShiftCommand => _shiftCommand ?? (_shiftCommand = new Command(obj =>
        {
            ToggleFlag();
            //接收通知
            TopKeys = GetToggle(ShiftFlag, TopKeys);
            MiddleKeys = GetToggle(ShiftFlag, MiddleKeys);
            BottomKeys = GetToggle(ShiftFlag, BottomKeys);
        }));

        private Command _languageCommand;
        public Command LanguageCommand => _languageCommand ?? (_languageCommand = new Command(obj =>
        {
            ShiftFlag = false;
            LanguageFlag();
            switch (CurrentLang)
            {
                case LanguageState.Eng:
                    TopKeys = EngTopKeys;
                    MiddleKeys = EngMiddleKeys;
                    BottomKeys = EngBottomKeys;
                    break;
                case LanguageState.Rus:
                    TopKeys = RusTopKeys;
                    MiddleKeys = RusMiddleKeys;
                    BottomKeys = RusBottomKeys;
                    break;
                default:
                    break;
            }
        }));

        //转换为大小写
        private ObservableCollection<KeyModel> GetToggle(Boolean flag, ObservableCollection<KeyModel> collection)
        {
            var newCollection = new ObservableCollection<KeyModel>();
            if (flag)
                foreach (var item in collection)
                {
                    newCollection.Add(new KeyModel(item.Name.ToUpper()));
                }
            else
                foreach (var item in collection)
                {
                    newCollection.Add(new KeyModel(item.Name.ToLower()));
                }
            return newCollection;
        }


        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        public void DoPropertyChanged(String Name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(Name));
            }
        }
        #endregion
    }
}
