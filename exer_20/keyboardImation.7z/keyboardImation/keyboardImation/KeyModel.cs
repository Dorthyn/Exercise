﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace keyboardImation
{
    class KeyModel
    {
        public KeyModel(String Name)
        {
            this.Name = Name;
        }

        public String Name
        {
            get;
        }
    }
}
